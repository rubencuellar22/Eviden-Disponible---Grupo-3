package com.grupotres.back_personal_disponible.repository;
 
import org.springframework.data.jpa.repository.JpaRepository;
 
import com.grupotres.back_personal_disponible.model.Grupo;
 
public interface GrupoRepository  extends JpaRepository<Grupo, Long> {
 
}
 