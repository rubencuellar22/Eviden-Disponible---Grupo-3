package com.grupotres.back_personal_disponible.serviceImplMy8;

public class JobTechnologyServiceImpl {

}
