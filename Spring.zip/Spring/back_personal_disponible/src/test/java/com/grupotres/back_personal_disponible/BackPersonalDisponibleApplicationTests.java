package com.grupotres.back_personal_disponible;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackPersonalDisponibleApplicationTests {

    @Test
    void contextLoads() {
    }

}
